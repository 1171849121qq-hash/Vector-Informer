# Vector-Informer archived network-core source preview

This preview exposes the archived network core associated with the Vector-Informer/TJ experiments, plus small CPU inference and metric helpers. It supports inspection of the architecture and its tensor interface. It is **not yet a complete, verified reproduction package for the paper's reported results**.

## What is included

| File | Role |
|---|---|
| `models/model.py` | Compact vehicle-history LSTM, complete vehicle/road graph, two GraphSAGE layers, temporal/social/road fusion and Informer decoder |
| `models/attn.py` | ProbSparse and full attention |
| `models/encoder.py`, `models/decoder.py`, `models/embed.py` | Temporal encoder, decoder and state embeddings |
| `models/social_pooling.py` | Archived MLP/convolution/pooling branch |
| `utils/masking.py` | Attention masks |
| `model_config.py` | Archived 42-feature, 128-dimensional, 8-head, 3-encoder-layer, 2-decoder-layer configuration |
| `run_inference.py` | New CPU helper for a separately supplied compatible checkpoint and preprocessed input |
| `evaluate_predictions.py` | New NumPy helper implementing the manuscript's explicitly defined coordinate-RMSE aggregation |
| `smoke_test.py`, `test_metrics.py` | Synthetic architecture check and analytic metric tests |

The seven network files come from `code/Vectornet-crat-Informer` in the project archive. Original and released hashes and all packaging changes are recorded in `SOURCE_PROVENANCE.json`. They are not claimed to be an independently recovered immutable training-run snapshot.

The checked local manuscript describes two mean-aggregating GraphSAGE layers of widths 2 → 32 → 6; this matches the active graph branch here. CGConv modules are present in the archived class definition but their forward calls are commented out. This preview should not be read as implementing a separate active CGConv branch in the final Vector network. It also does not include the independently configured Social-Informer or STG-Informer baselines.

## Quick check without data or weights

Tested environment: Python 3.13.5, PyTorch 2.8.0+cpu, PyG 2.6.1, NumPy 2.1.3, SciPy 1.15.3 on Windows CPU.

```bash
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python smoke_test.py
python -m unittest test_metrics.py
```

The smoke check constructs the archived architecture with **untrained** weights and synthetic inputs. A successful `(64,25,42)` output demonstrates tensor/graph execution only; it is not a forecasting result or a paper-metric reproduction. The metric tests use analytically known values and additionally check batch ordering and rejected inputs.

## Inference with a separately supplied checkpoint

```bash
python run_inference.py --checkpoint checkpoint.pth --input prepared_inputs.npz --output predicted_differences.npz --seed 0
```

This release does not include a checkpoint. The local TJ_14 candidate passed strict loading with 290 state-dictionary keys, and its CPU forward execution passed the synthetic consistency check. That establishes structural compatibility, not a verified mapping to every paper metric.

`prepared_inputs.npz` must contain numeric arrays loadable with `allow_pickle=False`:

| Field | Type and shape | Meaning |
|---|---|---|
| `x_enc` | float32 `(64,14,42)` | Normalized historical state differences |
| `x_dec` | float32 `(64,39,42)` | The 14 historical difference steps followed by 25 zero steps |
| `map_points` | float32 `(64,M,2)` | Normalized road-node coordinates, padded to capacity M |
| `map_mask` | bool `(64,M)` | True for valid nodes; each row requires at least one |

The 42 features represent seven vehicles with six state fields each: y, x, vy, vx, ay, ax. Fifteen observed positions produce fourteen differences. Output is 25 future **normalized differences**, not positions in metres. The helper preserves the archived reshape order.

Batch size is fixed at 64 in this snapshot. The social branch groups adjacent batch rows, so changing batch composition/order can change predictions. The compact history LSTM initializes hidden/cell states randomly, and ProbSparse samples keys randomly even in evaluation mode. `--seed` controls a new inference run; it is not asserted to recover the historical evaluation seed. Only CPU execution has been checked for this packaging release.

The earlier 64-window target-motion preview provides six target features. It does not contain the full vehicle/map inputs needed here and cannot be directly passed to this inference helper.

## Metric calculation

Inputs to the metric helper must be aligned predicted and ground-truth **positions in metres**, shape `(N,25,2)` at 5 Hz. Preserve the original row order and use complete batches of 64. No samples are silently dropped.

```bash
python evaluate_predictions.py --predictions predicted_positions.npy --targets ground_truth_positions.npy
```

For archived `(N,40,2)` arrays containing 15 history and 25 future positions, explicitly add `--history-steps 15`. NPZ inputs are also supported; select `--prediction-key` and `--target-key` if an archive contains multiple arrays.

The manuscript's ADE is the time average of the per-step coordinate RMSE across all samples and both coordinates. Its horizon FDE is the average of coordinate RMSE values computed separately within each consecutive 64-sample batch. These differ from mean Euclidean displacement ADE/FDE. The helper reports descriptive metric names and uses float64 accumulation; insignificant differences from the archived float32 calculation can occur.

**Do not feed normalized differences from `run_inference.py` to the position-metric helper.** Paired preprocessing and inverse transforms are required and are not included in this preview.

## What remains under verification

- Training code, data splits, paired local-map generation, normalization and inverse transforms, and an end-to-end real-data example are not included in this release.
- The archived full-window normalization path uses future-window statistics. It has not been validated as a history-only online inference procedure and is not being presented as one.
- Saved ordinary prediction files reproduce the rounded headline 0.75 ADE / 1.40 five-second FDE, but their three-second value rounds to 0.80 rather than the manuscript's 0.79. Complete matching map inputs and historical random state have not been recovered. No checkpoint is advertised as having reproduced every paper metric.

These boundaries are recorded so readers can distinguish inspectable source, runnable synthetic checks, structural checkpoint compatibility, and a future fully verified evaluation release.

## Licenses and attribution

See `LICENSE.md`, `THIRD_PARTY_NOTICES.md`, and `licenses/`. Informer-derived code retains Apache-2.0 terms, SocialGAN-derived code retains MIT terms, and CRAT-Pred-derived portions carry CC BY-NC 4.0 terms. The combined archived model is distributed for noncommercial research and is not uniformly MIT-licensed. New standalone helper files are MIT-licensed.
