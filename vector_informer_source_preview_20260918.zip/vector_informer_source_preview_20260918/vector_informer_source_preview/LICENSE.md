# Licensing of this source preview

Upstream-derived portions retain the licenses and attribution listed in `THIRD_PARTY_NOTICES.md` and the full texts in `licenses/`. In particular, the combined network includes CRAT-Pred-derived material under CC BY-NC 4.0 and must not be described as unrestricted commercial-use software.

Original Vector-Informer modifications in this archived combined network are provided for noncommercial research under Creative Commons Attribution-NonCommercial 4.0 International; see `licenses/CRAT-Pred-CC-BY-NC-4.0.txt` for the license terms. Attribution: Vector-Informer contributors, https://github.com/1171849121qq-hash/Vector-Informer. This does not remove rights separately granted for upstream Apache-2.0 or MIT components.

The new standalone packaging and verification helpers (`model_config.py`, `run_inference.py`, `smoke_test.py`, `evaluate_predictions.py`, and `test_metrics.py`) are provided under the MIT License below. They do not relicense the network modules they import. Existing released data remain under their separate data license.

## MIT License for the new helpers

Copyright (c) 2026 Vector-Informer contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
