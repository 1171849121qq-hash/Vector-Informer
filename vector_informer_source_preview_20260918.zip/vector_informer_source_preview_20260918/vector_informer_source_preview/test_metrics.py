"""Small analytic checks for the paper's nonstandard aggregation rules."""

import math
from pathlib import Path
import tempfile
import unittest

import numpy as np

from evaluate_predictions import evaluate, load_array, main


class PaperMetricsTests(unittest.TestCase):
    def test_coordinate_and_batch_aggregation(self):
        # At future step t, batch 1 has error (t, t), batch 2 (3t, 3t).
        # Global coordinate RMSE is sqrt(5)*t; mean batch RMSE is 2*t.
        steps = np.arange(1, 26, dtype=np.float64)[None, :, None]
        scales = np.array([1, 1, 3, 3], dtype=np.float64)[:, None, None]
        predictions = np.broadcast_to(scales * steps, (4, 25, 2)).copy()
        result = evaluate(predictions, np.zeros_like(predictions), batch_size=2)
        self.assertAlmostEqual(result["paper_coordinate_rmse_ade_m"], math.sqrt(5) * 13)
        self.assertEqual(
            result["paper_batch_mean_coordinate_rmse_fde_m"],
            {"1s": 10.0, "2s": 20.0, "3s": 30.0, "4s": 40.0, "5s": 50.0},
        )
        self.assertNotAlmostEqual(result["paper_coordinate_rmse_ade_m"], 2 * math.sqrt(2) * 13)
        self.assertNotAlmostEqual(result["paper_batch_mean_coordinate_rmse_fde_m"]["5s"], math.sqrt(5) * 25)
        # Mixing the same samples between batches changes FDE, not ADE.
        reordered = evaluate(predictions[[0, 2, 1, 3]], np.zeros_like(predictions), batch_size=2)
        self.assertAlmostEqual(reordered["paper_coordinate_rmse_ade_m"], result["paper_coordinate_rmse_ade_m"])
        self.assertAlmostEqual(reordered["paper_batch_mean_coordinate_rmse_fde_m"]["5s"], math.sqrt(5) * 25)

    def test_history_is_only_excluded_explicitly(self):
        predictions = np.ones((64, 40, 2), dtype=np.float32)
        predictions[:, :15] = 1000
        targets = np.zeros_like(predictions)
        with self.assertRaisesRegex(ValueError, "exactly 25"):
            evaluate(predictions, targets)
        result = evaluate(predictions, targets, history_steps=15)
        self.assertEqual(result["paper_coordinate_rmse_ade_m"], 1.0)
        self.assertEqual(result["paper_batch_mean_coordinate_rmse_fde_m"]["5s"], 1.0)
        self.assertTrue(result["batch_size_matches_manuscript"])

    def test_incomplete_batch_is_rejected(self):
        array = np.zeros((65, 25, 2), dtype=np.float64)
        with self.assertRaisesRegex(ValueError, "not divisible"):
            evaluate(array, array)

    def test_nonfinite_and_invalid_arrays_are_rejected(self):
        targets = np.zeros((64, 25, 2), dtype=np.float64)
        for value in (np.nan, np.inf, -np.inf):
            with self.subTest(value=value):
                predictions = targets.copy()
                predictions[0, 0, 0] = value
                with self.assertRaisesRegex(ValueError, "NaN or infinity"):
                    evaluate(predictions, targets)
        for invalid in (np.zeros((64, 25)), np.zeros((64, 25, 3)), np.zeros((0, 25, 2))):
            with self.subTest(shape=invalid.shape), self.assertRaisesRegex(ValueError, "shape"):
                evaluate(invalid, invalid)
        with self.assertRaisesRegex(ValueError, "floating-point"):
            evaluate(targets.astype(np.int64), targets)
        with self.assertRaisesRegex(ValueError, "identical shapes"):
            evaluate(targets, targets[:32])
        with self.assertRaisesRegex(ValueError, "overflow"):
            evaluate(np.full_like(targets, 1e308), targets)

    def test_numpy_io_and_cli_output(self):
        import json

        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            array = np.zeros((64, 25, 2), dtype=np.float32)
            predictions = directory / "predictions.npy"
            targets = directory / "targets.npz"
            output = directory / "metrics.json"
            np.save(predictions, array)
            np.savez(targets, truth=array, unrelated=np.zeros(1))
            with self.assertRaisesRegex(ValueError, "specify an array key"):
                load_array(targets)
            self.assertEqual(main([
                "--predictions", str(predictions), "--targets", str(targets),
                "--target-key", "truth", "--output", str(output),
            ]), 0)
            result = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(result["paper_coordinate_rmse_ade_m"], 0.0)
            self.assertEqual(result["sample_count"], 64)
            # Object arrays cannot be deserialized by the public loader.
            object_file = directory / "object.npy"
            np.save(object_file, np.array([{"payload": "not numeric"}], dtype=object))
            with self.assertRaises(ValueError):
                load_array(object_file)


if __name__ == "__main__":
    unittest.main()
