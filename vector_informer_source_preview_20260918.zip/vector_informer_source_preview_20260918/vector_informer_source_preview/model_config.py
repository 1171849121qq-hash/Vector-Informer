"""Archived TJ14-compatible configuration; not a paper reproduction guarantee.

New packaging helper, September 18, 2026. See LICENSE.md and THIRD_PARTY_NOTICES.md.
"""
from types import SimpleNamespace

import torch

from models.model import Informer


CONFIG = dict(enc_in=42, dec_in=42, c_out=42, seq_len=15, label_len=15,
              out_len=25, factor=5, d_model=128, n_heads=8, e_layers=3,
              d_layers=2, d_ff=128, dropout=0.01, attn='prob', embed='timeF',
              freq='h', activation='gelu', output_attention=False, distil=True, mix=True)


def build_model():
    args = SimpleNamespace(embedding_dim=64, encoder_h_dim=64, mlp_dim=128,
                           bottleneck_dim=64, mlp_activation='relu', batch_norm=False,
                           d_model=128, batch_size=64)
    model = Informer(args, **CONFIG, device=torch.device('cpu')).float().cpu()
    return model, args
