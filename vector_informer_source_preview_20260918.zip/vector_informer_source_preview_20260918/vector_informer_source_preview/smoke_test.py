"""Synthetic architecture check with untrained weights; not a forecasting evaluation."""
import json

import numpy as np
import torch

from model_config import build_model


def main():
    torch.set_num_threads(4)
    torch.manual_seed(20260918)
    rng = np.random.default_rng(20260918)
    x = torch.from_numpy(rng.normal(0, .1, (64, 14, 42)).astype(np.float32))
    decoder = torch.cat((x, torch.zeros((64, 25, 42))), dim=1)
    maps = [[rng.uniform(-1, 1, (3+i % 5, 2)).astype(np.float32)] for i in range(64)]
    model, args = build_model()
    model.eval()
    with torch.inference_mode():
        output = model(x, decoder, maps, args)
    assert output.shape == (64, 25, 42)
    assert torch.isfinite(output).all()
    print(json.dumps({'synthetic_architecture_check': 'passed', 'trained_weights_used': False,
                      'output_shape': list(output.shape), 'state_dict_keys': len(model.state_dict()),
                      'paper_metrics_verified': False}, indent=2))


if __name__ == '__main__':
    main()
