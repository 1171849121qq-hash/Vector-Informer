# Third-party sources and changes

This research source preview retains upstream licensing. It is not uniformly MIT- or Apache-licensed. The composite network includes code derived from CRAT-Pred, which carries a noncommercial restriction.

| Source | Attribution and link | License | Included adaptations |
|---|---|---|---|
| Informer | Haoyi Zhou and the Informer contributors; [official repository](https://github.com/zhouhaoyi/Informer2020) | Apache License 2.0; `licenses/Informer-Apache-2.0.txt` | Attention, embeddings, encoder/decoder, masks, and Informer portions of `models/model.py` |
| Social GAN | Copyright (c) 2018 Agrim Gupta, Justin Johnson; [official repository](https://github.com/agrimgupta92/sgan) | MIT; `licenses/SocialGAN-MIT.txt` | `make_mlp` and `PoolHiddenNet`-derived social pooling, extended in the archived project with convolutional layers |
| CRAT-Pred | Julian Schmidt, Julian Jordan, Franz Gritschneder, Klaus Dietmayer; [official repository](https://github.com/schmidt-ju/crat-pred) | Creative Commons Attribution-NonCommercial 4.0 International; `licenses/CRAT-Pred-CC-BY-NC-4.0.txt` | `EncoderLstm`, `AgentGnn` scaffolding and complete-graph construction in `models/model.py`, adapted to vehicle/map nodes and GraphSAGE |

The archived project adapted Informer to a 42-feature trajectory interface, combined temporal, social and road-node branches, added convolutional social pooling, and used two GraphSAGE layers for vehicle/road fusion. These are adaptations, not unchanged upstream files. The original repository does not establish an exact upstream commit for every adaptation; no exact upstream revision is asserted here.

The September 18, 2026 packaging changes normalize line endings and remove 12 hard-coded `.cuda()` calls from `models/social_pooling.py` for explicit CPU execution. Network layer definitions, parameter names, reshape order, stochastic forward operations and active graph operations are retained. Newly written configuration, inference, smoke-check and metric helpers are identified separately. `SOURCE_PROVENANCE.json` records original and released hashes.

Please retain these notices and the relevant license text when redistributing covered portions. The root repository's MIT license for its initial data-loading example does not relicense these upstream-derived files. No upstream author endorses this release.

Suggested upstream citations:

- Zhou et al. Informer: Beyond Efficient Transformer for Long Sequence Time-Series Forecasting. AAAI, 2021.
- Gupta et al. Social GAN: Socially Acceptable Trajectories with Generative Adversarial Networks. CVPR, 2018.
- Schmidt et al. CRAT-Pred: Vehicle Trajectory Prediction with Crystal Graph Convolutional Neural Networks and Multi-Head Self-Attention. ICRA, 2022, pp. 7799–7805.
