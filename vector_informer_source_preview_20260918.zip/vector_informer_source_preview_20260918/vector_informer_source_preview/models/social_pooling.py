# Archived Vector-Informer adaptation; source-preview packaging 2026-09-18.
# See THIRD_PARTY_NOTICES.md and LICENSE.md for upstream attribution and terms.
# Packaging change: removed 12 hard-coded .cuda() calls for CPU execution.
import torch
import torch.nn as nn



def make_mlp(dim_list, activation='relu', batch_norm=True, dropout=0):
    layers = []
    for dim_in, dim_out in zip(dim_list[:-1], dim_list[1:]):
        layers.append(nn.Linear(dim_in, dim_out))  # 构建MLP
        if batch_norm:
            layers.append(nn.BatchNorm1d(dim_out))  # 归一化
        if activation == 'relu':
            layers.append(nn.ReLU())
        elif activation == 'leakyrelu':
            layers.append(nn.LeakyReLU())
        elif activation == 'gelu':
            layers.append(nn.GELU())
        if dropout > 0:
            layers.append(nn.Dropout(p=dropout))
    return nn.Sequential(*layers)

def make_conv(dim_list, activation='relu', batch_norm=True, dropout=0):
    layers = []
    for dim_in, dim_out in zip(dim_list[:-1], dim_list[1:]):
        # conv
        layers.append(nn.Linear(dim_in, dim_out))  # 构建MLP
        if batch_norm:
            layers.append(nn.BatchNorm1d(dim_out))  # 归一化
        if activation == 'relu':
            layers.append(nn.ReLU())
        elif activation == 'leakyrelu':
            layers.append(nn.LeakyReLU())
        if dropout > 0:
            layers.append(nn.Dropout(p=dropout))
    return nn.Sequential(*layers)


class PoolHiddenNet(nn.Module):
    """Pooling module as proposed in our paper"""
    def __init__(
        self, embedding_dim=64, h_dim=64, mlp_dim=1024, bottleneck_dim=1024,tensor_embedding_layer_dim = 256,
        activation='relu', batch_norm=True, dropout=0.0
    ):
        super(PoolHiddenNet, self).__init__()

        self.mlp_dim = 1024
        self.h_dim = h_dim
        self.bottleneck_dim = bottleneck_dim
        self.embedding_dim = embedding_dim
        self.tensor_embedding_layer_dim = tensor_embedding_layer_dim
        mlp_pre_dim = embedding_dim + h_dim
        mlp_pre_pool_dims = [mlp_pre_dim, mlp_dim, bottleneck_dim]

        self.spatial_embedding = nn.Linear(42, embedding_dim)
        self.LayerNorm = nn.LayerNorm(bottleneck_dim)
        self.BatchNorm = nn.BatchNorm1d(bottleneck_dim)

        # 代替池化层作用 [4,1024]->[2,1024]
        self.temp = nn.Linear(4, 2)

        self.temp2 = nn.Linear(2048, 1024)

        self.conv_layer = nn.Conv1d(in_channels=4, out_channels=2, kernel_size=3, stride=1, padding=1)

        self.conv_laye2 = nn.Conv1d(in_channels=2, out_channels=2, kernel_size=2, stride=2, padding=0)

        self.conv_layer3 = nn.Conv1d(in_channels=2, out_channels=2, kernel_size=3, stride=1, padding=1)

        self.conv_layer4 = nn.Conv1d(in_channels=4, out_channels=4, kernel_size=3, stride=1, padding=1)

        self.average_pool1 = nn.AdaptiveAvgPool2d(output_size=(1,self.tensor_embedding_layer_dim))

        self.average_pool2 = nn.AdaptiveAvgPool2d(output_size=(2,1024))

        self.relu = nn.ReLU()
        self.leaky_relu = nn.LeakyReLU()
        self.conv_pre_pool = make_conv(
            mlp_pre_pool_dims,
            activation=activation,
            batch_norm=batch_norm,
            dropout=dropout)

    def repeat(self, tensor, num_reps):
        """
        Inputs:
        -tensor: 2D tensor of any shape
        -num_reps: Number of times to repeat each row
        Outpus:
        -repeat_tensor: Repeat each row such that: R1, R1, R2, R2
        """
        col_len = tensor.size(1)
        tensor = tensor.unsqueeze(dim=1).repeat(1, num_reps, 1)
        tensor = tensor.view(-1, col_len)
        return tensor

    def forward(self, h_states, seq_start_end, end_pos):
        """
        Inputs:
        - h_states: Tensor of shape (num_layers, batch, h_dim)
        - seq_start_end: A list of tuples which delimit sequences within batch
        - end_pos: Tensor of shape (batch, 2)
        Output:
        - pool_h: Tensor of shape (batch, bottleneck_dim)
        """
        pool_h = []
        for _, (start, end) in enumerate(seq_start_end):
            # start = start.item()
            # end = end.item()
            num_ped = end - start
            # 
            curr_hidden = h_states.view(-1, self.h_dim)[start:end]
            curr_end_pos = end_pos[start:end]
            # Repeat -> H1, H2, H1, H2
            curr_hidden_1 = curr_hidden.repeat(num_ped, 1)
            # Repeat position -> P1, P2, P1, P2
            curr_end_pos_1 = curr_end_pos.repeat(num_ped, 1)
            # Repeat position -> P1, P1, P2, P2
            curr_end_pos_2 = self.repeat(curr_end_pos, num_ped)
            curr_rel_pos = curr_end_pos_1 - curr_end_pos_2
            curr_rel_embedding = self.spatial_embedding(curr_rel_pos)
            mlp_h_input = torch.cat([curr_rel_embedding, curr_hidden_1], dim=1)  # [4,128]
            curr_pool_h = self.conv_pre_pool(mlp_h_input)  # MLP (4,1024)
            # mlponly1
            # curr_pool_h = self.temp(curr_pool_h.T)
            # curr_pool_h = curr_pool_h.T
            # mlponly3  !!
            # curr_pool_h = curr_pool_h.view(num_ped, -1) # (2,2048)
            # curr_pool_h = self.temp2(curr_pool_h)
            # mlponly2
            # curr_pool_h = self.conv_layer(curr_pool_h)
            # self.relu(curr_pool_h)
            # mlponly4 mlpconv2
            # curr_pool_h = self.conv_laye2(curr_pool_h.view(num_ped, -1))
            # mlpmix2
            # curr_pool_h = self.conv_layer(curr_pool_h)
            # self.relu(curr_pool_h)
            # curr_pool_h = self.conv_layer3(curr_pool_h)
            # mlpmix3
            curr_pool_h = self.conv_layer4(curr_pool_h)
            # self.relu(curr_pool_h)
            curr_pool_h = curr_pool_h.view(num_ped, num_ped, -1).max(1)[0]  # 最大池化 (2,1024)

            # mlppool1 *****!!!!  1.9
            # curr_pool_h = self.leaky_relu(self.BatchNorm(self.conv_layer4(curr_pool_h)))
            # curr_pool_h = self.average_pool1(curr_pool_h.view(num_ped, num_ped, -1))
            # curr_pool_h = curr_pool_h.squeeze(1)

            # mlppool2
            # curr_pool_h = curr_pool_h.unsqueeze(0)
            # curr_pool_h = self.average_pool2(curr_pool_h)
            # curr_pool_h = curr_pool_h.squeeze(0)
            # mlpmix1-
            # max(1)函数对(2,2,1024)后两维进行处理，沿着行的方向计算最大值。即取出(2,1024)每一列的最大值
            # curr_pool_h = curr_pool_h.view(num_ped, num_ped, -1).max(1)[0]  # 最大池化 (2,1024)

            pool_h.append(curr_pool_h)
        pool_h = torch.cat(pool_h, dim=0)
        return pool_h


def mlp_social_pooling_7(args, x_enc, hidden_states):
    # x_enc->[64,14,44] hidden_states->[1,64,64]

    tensor_embedding_layer = nn.Linear(1024, args.d_model)
    hidden_states = hidden_states.squeeze()
    use_cuda = args.use_cuda
    pool_net=PoolHiddenNet(
        embedding_dim=args.embedding_dim,
        h_dim=args.encoder_h_dim,  # 需要在args中加入对应变量
        mlp_dim=args.mlp_dim,
        bottleneck_dim=args.bottleneck_dim,
        activation=args.mlp_activation,
        batch_norm=args.batch_norm
    )
    # ?
    list1 = args.batch_size
    seq_start_end = [
        (start, end)
        for start, end in zip(range(0,list1,2), range(2,list1+1,2))
    ]
    end_pos = x_enc[:,-1,:]
    pool_h = pool_net(hidden_states, seq_start_end, end_pos)  # mlp + max_pool  [64,1024]
    pool_h = pool_h.unsqueeze(1)  # [64,1,1024]
    tensor_embedded = tensor_embedding_layer(pool_h)
    if use_cuda:
        tensor_embedded = tensor_embedded
    return tensor_embedded

