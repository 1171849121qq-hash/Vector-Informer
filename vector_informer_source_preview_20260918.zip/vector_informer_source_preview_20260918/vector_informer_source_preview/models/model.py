# Archived Vector-Informer adaptation; source-preview packaging 2026-09-18.
# See THIRD_PARTY_NOTICES.md and LICENSE.md for upstream attribution and terms.
# Packaging changes: provenance header and line-ending normalization only.
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torch.cuda import device
from torch_geometric.nn import conv, GCNConv, SAGEConv, GraphConv
from torch_geometric.utils import from_scipy_sparse_matrix
from scipy import sparse


from utils.masking import TriangularCausalMask, ProbMask
from models.encoder import Encoder, EncoderLayer, ConvLayer, EncoderStack
from models.decoder import Decoder, DecoderLayer
from models.attn import FullAttention, ProbAttention, AttentionLayer
from models.embed import DataEmbedding
from models.social_pooling import mlp_social_pooling_7, make_mlp, PoolHiddenNet

class Informer(nn.Module):
    def __init__(self, args, enc_in, dec_in, c_out, seq_len, label_len, out_len,
                factor=5, d_model=512, n_heads=8, e_layers=3, d_layers=2, d_ff=512, 
                dropout=0.0, attn='prob', embed='fixed', freq='h', activation='gelu', 
                output_attention = False, distil=True, mix=True,
                device=torch.device('cuda:0')):
        super(Informer, self).__init__()
        self.device = device
        self.pred_len = out_len
        self.attn = attn
        self.output_attention = output_attention
        # gnn
        self.encoder_lstm = EncoderLstm(latent_size=2, input_size=6).to(device)
        self.agent_gnn = AgentGnn(latent_size=2).to(device)
        # self.multihead_self_attention = MultiheadSelfAttention(latent_size=256).to(device)
        # Encoding
        self.enc_embedding = DataEmbedding(enc_in, d_model, embed, freq, dropout)
        self.enc_embedding_gnn = DataEmbedding(enc_in, d_model, embed, freq, dropout)
        self.dec_embedding = DataEmbedding(dec_in, d_model, embed, freq, dropout)
        # Attention
        Attn = ProbAttention if attn=='prob' else FullAttention
        # Encoder
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(Attn(False, factor, attention_dropout=dropout, output_attention=output_attention), 
                                d_model, n_heads, mix=False),
                    d_model,
                    d_ff,
                    dropout=dropout,
                    activation=activation
                ) for l in range(e_layers)
            ],
            [
                ConvLayer(
                    d_model
                ) for l in range(e_layers-1)
            ] if distil else None,
            norm_layer=torch.nn.LayerNorm(d_model)
        )
        self.encoder_gnn = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(Attn(False, factor, attention_dropout=dropout, output_attention=output_attention),
                                   d_model, n_heads, mix=False),
                    d_model,
                    d_ff,
                    dropout=dropout,
                    activation=activation
                ) for l in range(e_layers+1)
            ],
            [
                ConvLayer(
                    d_model
                ) for l in range(e_layers - 1)
            ] if distil else None,
            norm_layer=torch.nn.LayerNorm(d_model)
        )
        # Decoder
        self.decoder = Decoder(
            [
                DecoderLayer(
                    AttentionLayer(Attn(True, factor, attention_dropout=dropout, output_attention=False), 
                                d_model, n_heads, mix=mix),
                    AttentionLayer(FullAttention(False, factor, attention_dropout=dropout, output_attention=False), 
                                d_model, n_heads, mix=False),
                    d_model,
                    d_ff,
                    dropout=dropout,
                    activation=activation,
                )
                for l in range(d_layers)
            ],
            norm_layer=torch.nn.LayerNorm(d_model)
        )

        # MLP
        self.mlp = make_mlp(
            [42,256,512],
            activation=activation,
            batch_norm=True,
            dropout=0.1)
        # social pooling
        self.pool_net=PoolHiddenNet(
        embedding_dim=args.embedding_dim,
        h_dim=args.encoder_h_dim,  # 需要在args中加入对应变量
        mlp_dim=args.mlp_dim,
        bottleneck_dim=args.bottleneck_dim,
        activation=args.mlp_activation,
        batch_norm=args.batch_norm)
        # self.tensor_embedding_layer = nn.Linear(args.tensor_embedding_layer_dim, args.d_model)
        self.tensor_embedding_layer = nn.Linear(64, args.d_model)


        # self.end_conv1 = nn.Conv1d(in_channels=label_len+out_len, out_channels=out_len, kernel_size=1, bias=True)
        # self.end_conv2 = nn.Conv1d(in_channels=d_model, out_channels=c_out, kernel_size=1, bias=True)
        self.projection = nn.Linear(d_model, c_out, bias=True)
        # 尝试通过lstm网络获取隐藏状态，从而输入至social pooling进行编码
        self.lstm_1 = nn.LSTM(input_size=enc_in, hidden_size=64,num_layers=1, batch_first=True)
        self.lstm_2 = nn.LSTM(input_size=enc_in, hidden_size=64, num_layers=1, batch_first=True)
        # self.lstm_2 = nn.LSTM(input_size=enc_in, hidden_size=224,num_layers=1, batch_first=True)
        # self.lstm_3 = nn.LSTM(input_size=enc_in, hidden_size=224,num_layers=1, batch_first=True)
        # # --------------------------------------参数未设置！
        # self.tensor_embedding_layer = nn.Linear(self.grid_size * self.grid_size * self.rnn_size, self.embedding_size)
        #
        # # --------------------------------------

    def forward(self, x_enc, x_dec, batch_map, args,
                enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):
        #---crat-gnn
        # 构建地图节点特征
        # 首先合并子列表中的车道数据，顺便统计节点数目
        batch_map_resize = []

        for map_sample in batch_map:
            for i in range(len(map_sample)):
                if i == 0:
                    temp_data = map_sample[i]
                else:
                    temp_data = np.concatenate((temp_data,map_sample[i]),axis=0)
            batch_map_resize.append(temp_data)

        # batch_map_tensor =
        map_per_agent = []
        for i in range(len(batch_map_resize)):
            map_per_agent.append(batch_map_resize[i].shape[0])
        sum_map_node = sum(map_per_agent[i] for i in range(len(map_per_agent)))

        # 构建轨迹节点特征
        his_traj = x_enc
        displ = his_traj[:,:,:42]
        displ = displ.reshape((displ.size(0),displ.size(1),7,6))  # [batch_size,14,7,6]
        displ = displ.reshape((-1, displ.size(1), displ.size(-1)))  # [batch_size * 7, 14, 6]
        arr = np.zeros((his_traj.size(0),7,2))  # [batch_size,7,2]
        centers = torch.tensor(arr)
        centers[:,0,:] = his_traj[:, -1, :2]
        centers[:, 1, :] = his_traj[:, -1, 6:8]
        centers[:, 2, :] = his_traj[:, -1, 12:14]
        centers[:, 3, :] = his_traj[:, -1, 18:20]
        centers[:, 4, :] = his_traj[:, -1, 24:26]
        centers[:, 5, :] = his_traj[:, -1, 30:32]
        centers[:, 6, :] = his_traj[:, -1, 36:38]
        centers = centers.reshape((-1,centers.size(-1)))
        centers = centers.to(self.device)
        # Extract the number of agents in each sample of the current batch
        # 提取当前batch中每个样本中的agent的数量
        agents_per_sample = [7 for x in range(his_traj.size(0))]

        out_encoder_lstm = self.encoder_lstm(displ, agents_per_sample)  # [448,latent_size]=[64*7,64]

        # 2025.3.8 拼接车辆轨迹节点与车道信息节点
        node_per_sample = []
        for i in range(len(agents_per_sample)):
            temp_out_encoder_lstm = out_encoder_lstm[i * 7 : (i+1) * 7,:]
            temp_map = torch.from_numpy(batch_map_resize[i])
            temp_data = torch.cat((temp_out_encoder_lstm,temp_map.to(self.device)),dim=0)
            if i == 0:
                graph_data = temp_data
            else:
                graph_data = torch.cat((graph_data,temp_data),dim=0)
            node_per_sample.append(agents_per_sample[i]+map_per_agent[i])


        # 只使用最后一个隐藏状态h out_agent_gnn.shape = [448,6]
        out_agent_gnn = self.agent_gnn(
            graph_data.squeeze(), centers, node_per_sample)
        # 提取出[488,6]
        for i in range(len(node_per_sample)):
            if i == 0:
                crat_output = out_agent_gnn[:7,:]
            else:
                node_number = sum(node_per_sample[:i])
                crat_output = torch.cat((crat_output, out_agent_gnn[node_number:node_number+7,:]),dim = 0)

        # target：[448=64*7,6]
        crat_output = crat_output.reshape(64,1,42)
        # crat_output = crat_output.squeeze()
        # enc_out_gnn = self.mlp(crat_output)
        # enc_out_gnn = enc_out_gnn.unsqueeze(1)

        ## out_encoder_lstm = [448,14,512]
        # 使用lstm的输出，包含了所有时刻的信息
        # out_agent_gnn = torch.zeros_like(displ)
        # for i in range(14):
        #     out_encoder_lstm_temp = out_encoder_lstm[:,i,:]
        #     out_agent_gnn[:,i,:] = self.agent_gnn(
        #         out_encoder_lstm_temp, centers, agents_per_sample)


        # ----todo:2024.12.8
        # crat_output = out_agent_gnn.reshape((64,-1,42))  # [64,14,42]
        enc_out_gnn = self.enc_embedding_gnn(crat_output)  # [64,14,512]
        # enc_out_gnn, attns_gnn = self.encoder_gnn(enc_out_gnn, attn_mask=enc_self_mask)  # [64,4,512] 经历了两次stilling，14->7->4
        # -----


        #---Encoder

        enc_out = self.enc_embedding(x_enc)  # [64,14,512]
        enc_out, attns = self.encoder(enc_out, attn_mask=enc_self_mask)  # [64,4,512] 经历了两次stilling，14->7->4
        # attns [64,8,14,14] [64,8,7,7] [64,8,4,4]
        # ---crat-gnn

        #---Social pooling
        _,(h,c)=self.lstm_1(x_enc)  # out[14,64,64]  h[1,64,64]
        hidden_states = h.squeeze()
        list1 = args.batch_size
        seq_start_end = [
            (start, end)
            for start, end in zip(range(0, list1, 2), range(2, list1 + 1, 2))
        ]
        end_pos = x_enc[:, -1, :]
        pool_h = self.pool_net(hidden_states, seq_start_end, end_pos)  # mlp + max_pool  [64,1024]
        pool_h = pool_h.unsqueeze(1)  # [64,1,1024]
        tensor_embedded = self.tensor_embedding_layer(pool_h)

        # 两者结合转为三者结合？还是作为输入提供给
        enc_out = torch.cat((enc_out, tensor_embedded, enc_out_gnn), 1)  # [64,6,512]
        # enc_out = torch.cat((enc_out, tensor_embedded), 1)  # [64,6,512]
        # enc_out = torch.cat((enc_out, tensor_embedded, gnn_out), 1)  # [64,9,512]
        # enc_out = torch.cat((enc_out, crat_output), 1)  # [64,6,512]
        # -------------------------------------------------
        dec_out = self.dec_embedding(x_dec)  # [64,39,512]
        dec_out = self.decoder(dec_out, enc_out, x_mask=dec_self_mask, cross_mask=dec_enc_mask)  # [64,39,512]
        dec_out = self.projection(dec_out)
        
        # dec_out = self.end_conv1(dec_out)
        # dec_out = self.end_conv2(dec_out.transpose(2,1)).transpose(1,2)
        if self.output_attention:
            return dec_out[:,-self.pred_len:,:], attns
        else:
            return dec_out[:,-self.pred_len:,:] # [B, L, D]


class InformerStack(nn.Module):
    def __init__(self, enc_in, dec_in, c_out, seq_len, label_len, out_len, 
                factor=5, d_model=512, n_heads=8, e_layers=[3,2,1], d_layers=2, d_ff=512, 
                dropout=0.0, attn='prob', embed='fixed', freq='h', activation='gelu',
                output_attention = False, distil=True, mix=True,
                device=torch.device('cuda:0')):
        super(InformerStack, self).__init__()
        self.pred_len = out_len
        self.attn = attn
        self.output_attention = output_attention

        # Encoding
        self.enc_embedding = DataEmbedding(enc_in, d_model, embed, freq, dropout)
        self.dec_embedding = DataEmbedding(dec_in, d_model, embed, freq, dropout)
        # Attention
        Attn = ProbAttention if attn=='prob' else FullAttention
        # Encoder

        inp_lens = list(range(len(e_layers))) # [0,1,2,...] you can customize here
        encoders = [
            Encoder(
                [
                    EncoderLayer(
                        AttentionLayer(Attn(False, factor, attention_dropout=dropout, output_attention=output_attention), 
                                    d_model, n_heads, mix=False),
                        d_model,
                        d_ff,
                        dropout=dropout,
                        activation=activation
                    ) for l in range(el)
                ],
                [
                    ConvLayer(
                        d_model
                    ) for l in range(el-1)
                ] if distil else None,
                norm_layer=torch.nn.LayerNorm(d_model)
            ) for el in e_layers]
        self.encoder = EncoderStack(encoders, inp_lens)
        # Decoder
        self.decoder = Decoder(
            [
                DecoderLayer(
                    AttentionLayer(Attn(True, factor, attention_dropout=dropout, output_attention=False), 
                                d_model, n_heads, mix=mix),
                    AttentionLayer(FullAttention(False, factor, attention_dropout=dropout, output_attention=False), 
                                d_model, n_heads, mix=False),
                    d_model,
                    d_ff,
                    dropout=dropout,
                    activation=activation,
                )
                for l in range(d_layers)
            ],
            norm_layer=torch.nn.LayerNorm(d_model)
        )
        # self.end_conv1 = nn.Conv1d(in_channels=label_len+out_len, out_channels=out_len, kernel_size=1, bias=True)
        # self.end_conv2 = nn.Conv1d(in_channels=d_model, out_channels=c_out, kernel_size=1, bias=True)
        self.projection = nn.Linear(d_model, c_out, bias=True)
        
    def forward(self, x_enc, x_dec, args, enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):
        # enc_out = self.enc_embedding(x_enc, x_mark_enc)
        # enc_out, attns = self.encoder(enc_out, attn_mask=enc_self_mask)

        # dec_out = self.dec_embedding(x_dec, x_mark_dec)
        # dec_out = self.decoder(dec_out, enc_out, x_mask=dec_self_mask, cross_mask=dec_enc_mask)
        # dec_out = self.projection(dec_out)
        
        enc_out = self.enc_embedding(x_enc)  # [64,14,512]
        enc_out, attns = self.encoder(enc_out, attn_mask=enc_self_mask)  # [64,4,512] 经历了两次stilling，14->7->4
        # -------------------------------------------------
        # grids, nodesPresent, hidden_states = prepare_social(args, x_enc)
        # tensor_embedded = social_pooling(args, grids[:-1], nodesPresent[:-1], hidden_states)
        # enc_out = torch.cat((enc_out, tensor_embedded), 1)  # 1 ?
        # -------------------------------------------------
        dec_out = self.dec_embedding(x_dec)  # [64,39,512]
        dec_out = self.decoder(dec_out, enc_out, x_mask=dec_self_mask, cross_mask=dec_enc_mask)  # [64,39,512]
        dec_out = self.projection(dec_out)


        # dec_out = self.end_conv1(dec_out)
        # dec_out = self.end_conv2(dec_out.transpose(2,1)).transpose(1,2)
        if self.output_attention:
            return dec_out[:,-self.pred_len:,:], attns
        else:
            return dec_out[:,-self.pred_len:,:] # [B, L, D]


class EncoderLstm(nn.Module):
    def __init__(self, latent_size, input_size):
        super(EncoderLstm, self).__init__()
        self.input_size = input_size
        self.hidden_size = latent_size
        self.num_layers = 1

        self.lstm = nn.LSTM(
            input_size=self.input_size,
            hidden_size=self.hidden_size,
            num_layers=self.num_layers,
            batch_first=True,
        )

    def forward(self, lstm_in, agents_per_sample):
        # lstm_in are all agents over all samples in the current batch
        # Format for LSTM has to be has to be (batch_size, timeseries_length, latent_size), because batch_first=True

        # Initialize the hidden state.
        # lstm_in.shape[0] corresponds to the number of all agents in the current batch
        lstm_hidden_state = torch.randn(
            self.num_layers, lstm_in.shape[0], self.hidden_size, device=lstm_in.device)
        lstm_cell_state = torch.randn(
            self.num_layers, lstm_in.shape[0], self.hidden_size, device=lstm_in.device)
        lstm_hidden = (lstm_hidden_state, lstm_cell_state)

        lstm_out, (h,c) = self.lstm(lstm_in, lstm_hidden)

        # lstm_out is the hidden state over all time steps from the last LSTM layer
        # In this case, only the features of the last time step are used
        return lstm_out[:, -1, :]
        # return h
        # return lstm_out

class AgentGnn(nn.Module):
    def __init__(self, latent_size):
        super(AgentGnn, self).__init__()
        self.latent_size = latent_size
        self.gcn1 = conv.CGConv(self.latent_size, dim=2, batch_norm=True)
        self.gcn2 = conv.CGConv(self.latent_size, dim=2, batch_norm=True)
        self.conv1 = GCNConv(latent_size, 128)
        self.conv2 = GCNConv(128, 42)
        self.graphSAGE1 = SAGEConv(in_channels=latent_size,out_channels=32)
        self.graphSAGE2 = SAGEConv(in_channels=32, out_channels=6)
    def forward(self, gnn_in, centers, agents_per_sample):
        # gnn_in is a batch and has the shape (batch_size, number_of_agents, latent_size)
        # gnn_in = gnn_in.reshape((64,-1,self.latent_size))
        x, edge_index = gnn_in, self.build_fully_connected_edge_idx(
            agents_per_sample).to(gnn_in.device)
        # edge_attr = self.build_edge_attr(edge_index, centers).to(gnn_in.device)
        #
        # x = F.relu(self.gcn1(x=x, edge_index=edge_index, edge_attr=edge_attr))
        # gnn_out = F.relu(self.gcn2(x=x, edge_index=edge_index, edge_attr=edge_attr))

        # x = F.relu(self.conv1(x, edge_index))
        # gnn_out = F.relu(self.conv2(x, edge_index))
        x = F.relu(self.graphSAGE1(x, edge_index))
        gnn_out = F.relu(self.graphSAGE2(x, edge_index))


        return gnn_out

    def build_fully_connected_edge_idx(self, agents_per_sample):
        edge_index = []

        # In the for loop one subgraph is built (no self edges!)
        # The subgraph gets offsetted and the full graph over all samples in the batch
        # gets appended with the offsetted subgrah
        offset = 0
        for i in range(len(agents_per_sample)):
            num_nodes = agents_per_sample[i]

            adj_matrix = torch.ones((num_nodes, num_nodes))
            adj_matrix = adj_matrix.fill_diagonal_(0)  # fill_diagonal_函数用于填充至少二维张量的主对角线

            sparse_matrix = sparse.csr_matrix(adj_matrix.numpy())  # csr_matrix表示压缩稀疏行矩阵
            # 将一个scipy稀疏矩阵转换为边索引和边属性
            edge_index_subgraph, _ = from_scipy_sparse_matrix(sparse_matrix)

            # Offset the list 偏移列表
            edge_index_subgraph = torch.Tensor(
                np.asarray(edge_index_subgraph) + offset)
            offset += agents_per_sample[i]

            edge_index.append(edge_index_subgraph)

        # Concat the single subgraphs into one 将单个子图联接为一个
        edge_index = torch.LongTensor(np.column_stack(edge_index))
        return edge_index

    def build_edge_attr(self, edge_index, data):
        edge_attr = torch.zeros((edge_index.shape[-1], 2), dtype=torch.float32)

        rows, cols = edge_index
        # goal - origin
        edge_attr = data[cols] - data[rows]

        return edge_attr.to(torch.float32)


class MultiheadSelfAttention(nn.Module):
    def __init__(self, latent_size):
        super(MultiheadSelfAttention, self).__init__()
        self.latent_size = latent_size
        self.multihead_attention = nn.MultiheadAttention(self.latent_size, 4)

    def forward(self, att_in, agents_per_sample):
        att_out_batch = []

        # Upper path is faster for multiple samples in the batch and vice versa
        if len(agents_per_sample) > 1:
            max_agents = max(agents_per_sample)

            padded_att_in = torch.zeros(
                (len(agents_per_sample), max_agents, self.latent_size), device=att_in[0].device)
            mask = torch.arange(max_agents) < torch.tensor(
                agents_per_sample)[:, None]

            padded_att_in[mask] = att_in

            mask_inverted = ~mask
            mask_inverted = mask_inverted.to(att_in.device)

            padded_att_in_swapped = torch.swapaxes(padded_att_in, 0, 1)

            padded_att_in_swapped, _ = self.multihead_attention(
                padded_att_in_swapped, padded_att_in_swapped, padded_att_in_swapped,
                key_padding_mask=mask_inverted)

            padded_att_in_reswapped = torch.swapaxes(
                padded_att_in_swapped, 0, 1)

            att_out_batch = [x[0:agents_per_sample[i]]
                             for i, x in enumerate(padded_att_in_reswapped)]
        else:
            att_in = torch.split(att_in, agents_per_sample)
            for i, sample in enumerate(att_in):
                # Add the batch dimension (this has to be the second dimension, because attention requires it)
                att_in_formatted = sample.unsqueeze(1)
                att_out, weights = self.multihead_attention(
                    att_in_formatted, att_in_formatted, att_in_formatted)

                # Remove the "1" batch dimension
                att_out = att_out.squeeze()
                att_out_batch.append(att_out)

        return att_out_batch