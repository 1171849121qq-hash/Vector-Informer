"""CPU inference with a separately supplied trusted compatible state_dict.

Inputs must already be normalized; this helper does not reproduce preprocessing.
New packaging helper, September 18, 2026. See LICENSE.md.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from model_config import build_model


def load_inputs(path):
    with np.load(path, allow_pickle=False) as data:
        x, dec, points, mask = [data[k] for k in ('x_enc', 'x_dec', 'map_points', 'map_mask')]
    if x.shape != (64, 14, 42) or dec.shape != (64, 39, 42):
        raise ValueError('Expected x_enc=(64,14,42), x_dec=(64,39,42).')
    if points.ndim != 3 or points.shape[0] != 64 or points.shape[2] != 2 or mask.shape != points.shape[:2]:
        raise ValueError('Expected map_points=(64,M,2), map_mask=(64,M).')
    if any(a.dtype != np.float32 for a in (x, dec, points)) or mask.dtype != np.bool_:
        raise ValueError('State/map arrays must be float32; map_mask must be bool.')
    if not all(np.isfinite(a).all() for a in (x, dec, points)) or not mask.any(axis=1).all():
        raise ValueError('Inputs must be finite; each row needs at least one valid map node.')
    if not np.array_equal(dec[:, :14], x) or np.any(dec[:, 14:] != 0):
        raise ValueError('Decoder input must contain 14 observed difference steps then 25 zero steps.')
    maps = [[points[i, mask[i]].copy()] for i in range(64)]
    return torch.from_numpy(x), torch.from_numpy(dec), maps


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seed', type=int, default=0, help='New inference seed, not an archived paper seed.')
    args = parser.parse_args()
    if args.output.suffix != '.npz' or args.output.exists():
        parser.error('Choose a new .npz output path.')
    x, dec, maps = load_inputs(args.input)
    torch.set_num_threads(4)
    model, config = build_model()
    state = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    model.load_state_dict(state, strict=True)
    model.eval()
    torch.manual_seed(args.seed)
    with torch.inference_mode():
        out = model(x, dec, maps, config)
    if out.shape != (64, 25, 42) or not torch.isfinite(out).all():
        raise ValueError('Unexpected or non-finite output.')
    digest = hashlib.sha256(args.checkpoint.read_bytes()).hexdigest()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.output, predicted_normalized_differences=out.numpy(),
                        checkpoint_sha256=np.array(digest), seed=np.array(args.seed))
    print(json.dumps({'output_shape': list(out.shape), 'output_units': 'normalized differences',
                      'checkpoint_sha256': digest, 'seed': args.seed,
                      'paper_metrics_verified': False}, indent=2))


if __name__ == '__main__':
    main()
