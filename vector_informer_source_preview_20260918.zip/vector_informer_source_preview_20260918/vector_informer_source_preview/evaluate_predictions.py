#!/usr/bin/env python3
"""Calculate the coordinate-RMSE metrics reported in the current manuscript.

Inputs must be aligned prediction/target positions in metres, with shape
(N, 25, 2) at 5 Hz. For archived arrays containing 15 history and 25 future
positions, pass --history-steps 15 explicitly. Coordinates must already be
converted back to physical units; this script performs no normalization.

Paper ADE: calculate RMSE over samples AND the two coordinates at each future
step, then average those 25 RMSE values. Paper FDE: calculate coordinate RMSE
within each consecutive, equal-sized batch at a requested horizon, then
average across batches. The manuscript uses batches of 64; preserve the
original sample order. These are not the usual mean Euclidean ADE/FDE.

Recalculating metrics from saved predictions does not establish checkpoint
provenance or demonstrate that model inference reproduces the paper.

Only NumPy and the Python standard library are required. NumPy files must
contain numeric floating-point arrays; pickled objects are never loaded.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np


FUTURE_STEPS = 25
SAMPLE_RATE_HZ = 5
HORIZONS_SECONDS = (1, 2, 3, 4, 5)


def load_array(path: str | Path, key: str | None = None) -> np.ndarray:
    """Load one .npy array or a named (or sole) array from a .npz archive."""
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix not in {".npy", ".npz"}:
        raise ValueError(f"{path}: expected a .npy or .npz file")
    if suffix == ".npy":
        if key is not None:
            raise ValueError(f"{path}: an array key is only valid for .npz files")
        return np.load(path, allow_pickle=False)
    with np.load(path, allow_pickle=False) as archive:
        if key is None:
            if len(archive.files) != 1:
                raise ValueError(
                    f"{path}: specify an array key for an archive containing "
                    f"{len(archive.files)} arrays"
                )
            key = archive.files[0]
        if key not in archive.files:
            raise ValueError(f"{path}: array key {key!r} was not found")
        return archive[key]


def _validate_array(array: np.ndarray, name: str) -> None:
    if not isinstance(array, np.ndarray):
        raise ValueError(f"{name} must be a NumPy array")
    if array.ndim != 3 or array.shape[2] != 2 or array.shape[0] == 0:
        raise ValueError(f"{name} must have nonempty shape (N, T, 2)")
    if not np.issubdtype(array.dtype, np.floating):
        raise ValueError(f"{name} must have a real floating-point dtype")
    if not np.isfinite(array).all():
        raise ValueError(f"{name} contains NaN or infinity")


def evaluate(
    predictions: np.ndarray,
    targets: np.ndarray,
    *,
    history_steps: int = 0,
    batch_size: int = 64,
) -> dict:
    """Return the manuscript's metrics without reordering or dropping rows."""
    if isinstance(history_steps, bool) or not isinstance(history_steps, int) or history_steps < 0:
        raise ValueError("history_steps must be a nonnegative integer")
    if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size <= 0:
        raise ValueError("batch_size must be a positive integer")
    _validate_array(predictions, "predictions")
    _validate_array(targets, "targets")
    if predictions.shape != targets.shape:
        raise ValueError("predictions and targets must have identical shapes")
    n_samples, n_steps, _ = predictions.shape
    if n_steps != history_steps + FUTURE_STEPS:
        raise ValueError(
            f"expected exactly {history_steps + FUTURE_STEPS} input steps "
            f"({history_steps} history + {FUTURE_STEPS} future), got {n_steps}"
        )
    if n_samples % batch_size:
        raise ValueError(
            f"sample count {n_samples} is not divisible by batch size {batch_size}; "
            "no samples will be dropped"
        )

    # Float64 arithmetic avoids accumulating squared errors in float32.
    future_predictions = predictions[:, history_steps:, :].astype(np.float64)
    future_targets = targets[:, history_steps:, :].astype(np.float64)
    try:
        with np.errstate(over="raise", invalid="raise"):
            squared_errors = np.square(future_predictions - future_targets)
            coordinate_rmse_per_step = np.sqrt(squared_errors.mean(axis=(0, 2)))
            batch_errors = squared_errors.reshape(-1, batch_size, FUTURE_STEPS, 2)
            batch_coordinate_rmse_per_step = np.sqrt(batch_errors.mean(axis=(1, 3)))
            batch_mean_coordinate_rmse_per_step = batch_coordinate_rmse_per_step.mean(axis=0)
            ade = float(coordinate_rmse_per_step.mean())
    except FloatingPointError as exc:
        raise ValueError("input magnitudes overflow float64 metric calculations") from exc

    return {
        "metric_definition": "manuscript_coordinate_rmse_v1",
        "units": "metres",
        "sample_count": n_samples,
        "input_steps": n_steps,
        "excluded_history_steps": history_steps,
        "future_steps": FUTURE_STEPS,
        "sample_rate_hz": SAMPLE_RATE_HZ,
        "batch_size": batch_size,
        "batch_count": n_samples // batch_size,
        "batch_size_matches_manuscript": batch_size == 64,
        "paper_coordinate_rmse_ade_m": ade,
        "paper_batch_mean_coordinate_rmse_fde_m": {
            f"{seconds}s": float(batch_mean_coordinate_rmse_per_step[seconds * SAMPLE_RATE_HZ - 1])
            for seconds in HORIZONS_SECONDS
        },
        "coordinate_rmse_by_future_step_m": coordinate_rmse_per_step.tolist(),
        "definitions": {
            "ade": "mean_over_time(sqrt(mean_over_samples_and_coordinates(squared_error)))",
            "fde": "mean_over_batches(sqrt(mean_over_batch_samples_and_coordinates(squared_error_at_horizon)))",
        },
        "notes": [
            "Inputs are assumed to be aligned positions in physical metres at 5 Hz.",
            "Consecutive input rows define batches; sample order is preserved and affects FDE.",
            "The manuscript uses batch size 64; other batch sizes are diagnostic only.",
            "These metrics differ from mean Euclidean ADE/FDE.",
            "Metric agreement alone does not verify a checkpoint or reproduce model inference.",
        ],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--predictions", required=True, type=Path, help="predicted positions (.npy or .npz)")
    parser.add_argument("--targets", required=True, type=Path, help="aligned ground-truth positions (.npy or .npz)")
    parser.add_argument("--prediction-key", help="prediction array key if .npz contains multiple arrays")
    parser.add_argument("--target-key", help="target array key if .npz contains multiple arrays")
    parser.add_argument("--history-steps", type=int, default=0, help="history positions to exclude (default: 0; archived T=40: 15)")
    parser.add_argument("--batch-size", type=int, default=64, help="consecutive rows per batch (manuscript: 64)")
    parser.add_argument("--output", type=Path, help="optional output JSON file; otherwise print to stdout")
    args = parser.parse_args(argv)

    try:
        if args.output is not None and args.output.resolve() in {
            args.predictions.resolve(), args.targets.resolve()
        }:
            raise ValueError("output must not overwrite an input array")
        result = evaluate(
            load_array(args.predictions, args.prediction_key),
            load_array(args.targets, args.target_key),
            history_steps=args.history_steps,
            batch_size=args.batch_size,
        )
        payload = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
        if args.output is None:
            sys.stdout.write(payload)
        else:
            args.output.write_text(payload, encoding="utf-8")
    except (OSError, ValueError, TypeError) as exc:
        parser.error(str(exc))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
